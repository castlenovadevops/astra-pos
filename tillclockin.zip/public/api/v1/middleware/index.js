const accessAuth = require('./access');
const authorizationAuth = require('./authorization');

module.exports = {
    accessAuth,
    authorizationAuth
}