import React from "react";
import PropTypes from 'prop-types';
import { Button, Grid, Dialog, DialogActions, DialogTitle, DialogContent, DialogContentText } from "@mui/material"; 
import Loader from "../../components/Loader";
import Iconify from '../../components/Iconify';
import HTTPManager from "../../utils/httpRequestManager";

import SwipeableViews from 'react-swipeable-views'; 
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Technicians from "./technicians";
import Clockin from './clockin';

const getIcon = (name) => <Iconify icon={name} width={22} height={22} />;

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`full-width-tabpanel-${index}`}
      aria-labelledby={`full-width-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `full-width-tab-${index}`,
    'aria-controls': `full-width-tabpanel-${index}`,
  };
}

export default class MerchantDashboard extends React.Component{
    httpmanager = new HTTPManager(); 

    constructor(){
        super();
        this.state={
            userdetail:{},
            requestNewBusiness: false,
            isLoading: false,
            value:0,
            showClockIn: false
        }
        this.loadData = this.loadData.bind(this); 
        this.handleChangeIndex = this.handleChangeIndex.bind(this);
        this.handleChange = this.handleChange.bind(this)
        this.handleCloseDialog = this.handleCloseDialog.bind(this);
    }

    handleCloseDialog(){
        this.setState({showClockIn: false})
    }
    componentDidMount(){ 
        this.loadData()
    }

    handleChange(event, newValue){
        this.setState({value:newValue});
    };

    handleChangeIndex(index) {
        this.setState({value:index});
    };

    loadData(){

        var details = window.localStorage.getItem("userdetail") || ''
        if(details !== ''){
            this.setState({userdetail: JSON.stringify(details)}, ()=>{
                // this.getBusinessMetrics();
            })
        }
    } 

    render(){
        return <div className="fullHeight">  
            {this.state.isLoading && <Loader />}
           
            <Grid container className="fullHeight">
                <Grid item xs={4} className={'dashboardDivider'}>
                    <Technicians />
                </Grid>
                <Grid item xs={8} className={'dashboardDivider'}>
                    <Box>
                    <Tabs
                    value={this.state.value}
                    onChange={this.handleChange}
                    indicatorColor="primary"
                    textColor="inherit"
                    variant="fullWidth"
                    aria-label="full width tabs example"
                    >
                        <Tab label="Item One" {...a11yProps(0)} />
                        <Tab label="Item Two" {...a11yProps(1)} />
                        <Tab label="Item Three" {...a11yProps(2)} />
                    </Tabs>
                    
                    <SwipeableViews
                        axis={'x'}
                        index={this.state.value}
                        onChangeIndex={this.handleChangeIndex}
                    >
                        <TabPanel value={this.state.value} index={0} dir={'ltr'}>
                        Item One
                        </TabPanel>
                        <TabPanel value={this.state.value} index={1} dir={'ltr'}>
                        Item Two
                        </TabPanel>
                        <TabPanel value={this.state.value} index={2} dir={'ltr'}>
                        Item Three
                        </TabPanel>
                    </SwipeableViews>
                    </Box>
                </Grid>
            </Grid>

            <Grid container>
                <Grid item xs={12} className="dashboardFooter">
                    <Grid item xs={2} className={'dashboardFooterDivider active'} onClick={()=>{
                        this.setState({showClockIn: true})
                    }}>
                        Clock-In / Clock-Out
                    </Grid>
                    <Grid item xs={2} className={'dashboardFooterDivider active'}>
                        Create Ticket
                    </Grid>
                    <Grid item xs={2} className={'dashboardFooterDivider '}>
                        Check-In
                    </Grid>
                    <Grid item xs={2} className={'dashboardFooterDivider '}>
                        Waiting List
                    </Grid> 
                    <Grid item xs={2} className={'dashboardFooterDivider '}>
                        Appointments
                    </Grid>
                    <Grid item xs={2} className={'dashboardFooterDivider active'}>
                        Report
                    </Grid>
                </Grid>
            </Grid>



    <Dialog
                    open={this.state.showClockIn}
                    onClose={this.handleCloseDialog}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description"
                >
                    <DialogTitle id="alert-dialog-title">
                        Clock-In / Clock-Out
                    </DialogTitle>
                    <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        <Clockin handleCloseDialog={()=>{
                                this.setState({showClockIn: false})
                        }} />
                    </DialogContentText>
                    </DialogContent> 
                </Dialog>

        </div>
    }
}